# FIAP 2023 CP2
## Checkpoint 2 - AC na Web
## João Augusto Rudge RM:87725
